print('Cost to operate the server per day:',0.51*24,'$\n\n')
print('Cost to operate the server per week:',0.51*24*7,'$\n\n')
print('Cost to operate the server per month(30 days):',0.51*24*30,'$\n\n')
print('Days the server can operate with $918:',(918//.51)//24,'days\n\n')
