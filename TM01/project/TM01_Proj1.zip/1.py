z=int(input('How far would you want to travel in miles?'))
if(z<3):
  print('I suggest Bicycle to your destination')
elif(z<300):
  print('I suggest Motor-Cycle to your destination')
else:
  print('I suggest Super-Car to your destination')