for x in range(23,57):
  if(x%2==0):
    print(x)