v=input("Enter the number to check")
if(int(v)%2==0):
  print("Even")
else:
  print("Odd")