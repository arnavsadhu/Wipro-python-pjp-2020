v1=input("Enter the 1st number")
v2=input("Enter the 1st number")
if((int(v1)%10)==(int(v2)%10)):
  print("True")
else:
  print("False")