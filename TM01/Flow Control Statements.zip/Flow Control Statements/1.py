v=input("Enter the number to check")
if(int(v)>0):
  print("positive")
elif(int(v)<0):
  print("negative")
else:
  print("Zero")