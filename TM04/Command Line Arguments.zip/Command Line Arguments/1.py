# -*- coding: utf-8 -*-
"""
Created on Sat Mar 14 01:08:16 2020

@author: Arnav
"""

from sys import argv
print("sum: ",((int(argv[1]))+(int(argv[2]))))