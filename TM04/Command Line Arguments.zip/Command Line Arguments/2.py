# -*- coding: utf-8 -*-
"""
Created on Fri Mar 13 23:51:13 2020

@author: Arnav
"""
from sys import argv
z=argv[1]
print(z)
print("file name is:", argv[0])