
try:
  z=int(input("Enter numbers to divide:"))
  x=int(input("Divided by:"))
  p=z/x
except:
  print("An exception has occured")
else:
  print("Results: ",p)
