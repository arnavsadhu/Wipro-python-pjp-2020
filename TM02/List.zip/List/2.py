ls=['physics', 'chemistry', 'Maths']
print(ls)
x=input("enter subject to append: ")
ls.append(x)
print(ls)
