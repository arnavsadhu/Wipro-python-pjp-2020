list1 = ['physics', 'chemistry', 1997, 2000]
list2 = [1, 2, 3, 4, 5, 6, 7 ]
print(list1)
print(list2)

ls3=list1+list2
list2=ls3

print(list1)
print(list2)