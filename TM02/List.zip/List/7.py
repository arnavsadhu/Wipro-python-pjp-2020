list1 = ['physics', 'chemistry','maths','bio']
print(list1)

x=int(input('enter item index to be removed:'))
del list1[x]

print(list1)