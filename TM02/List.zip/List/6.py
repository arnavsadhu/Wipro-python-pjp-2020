list1 = ['physics', 'chemistry','maths','bio']
print(list1)

list1.reverse()
x=input('enter item to append at the beginning:')
list1.append(x)
list1.reverse()

print(list1)