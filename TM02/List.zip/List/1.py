ls=[]

print('Input 5 elements into the list')
for p in range(5):
  x=input()
  ls.append(x)

for p in range(5):
  print (ls[p])
