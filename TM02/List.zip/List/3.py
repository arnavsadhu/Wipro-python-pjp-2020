ls=['physics', 'chemistry', 'Maths']
print(ls)
ls.reverse()
print(ls)