ls=['physics', 'chemistry', 'Maths','physics']
print(ls)
ls.count('physics')
