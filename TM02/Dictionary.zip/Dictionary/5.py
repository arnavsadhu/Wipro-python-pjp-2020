dic={}
for z in range (1,16):
    dic[z]=z**2
print(dic)