dic={1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}
print('---Keys---\n')
for z in dic:
    print(z,'\n')
print('---Values---')
for z in dic:
    print(dic[z],'\n')
print('---Keys---')
for z in dic:
    print(z,':',dic[z],'\n')
