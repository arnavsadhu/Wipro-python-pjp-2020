dic={0: 10, 1: 20}
print(dic)
dic[2]=30
print(dic)
