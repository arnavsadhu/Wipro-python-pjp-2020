dic={1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}
print(dic)
sum=0
for z in dic:
    sum+=dic[z]
print('sum:',sum)