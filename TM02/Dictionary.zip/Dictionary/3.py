dic={1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}
z=int(input('Enter key to search: '))
if z in dic:
    print('present')
else:
    print('not present')