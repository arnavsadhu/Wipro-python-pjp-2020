set1={1,2,3,4,5,6,7,42,34,23}

print('max:',max(set1))
print('min',min(set1))