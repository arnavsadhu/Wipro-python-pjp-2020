set1={1,2,3,4,5,6,7,42,34,23}
set2={5,6431,2,34}
set3=set1|set2

print(set3)