set1={'ad',4,'www',233}
print(set1)
set1.remove('ad')
print(set1)