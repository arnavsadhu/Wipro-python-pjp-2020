tup=(1,2,3,4,5,55,3324,243,243,324,432,432234,346,345,12,4,31,434,56,36,4)
print('4th element from beginning:',tup[3])
print('4th element from end:',tup[-4])
