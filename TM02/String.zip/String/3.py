s=input('Enter string:')
it=s[:2]
z=''
for x in range((len(s))):
    z+=it
print(z)