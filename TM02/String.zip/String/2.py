s=input('enter string to check:')
rev=s[::-1]
if(s==rev):
    print('yes')
else:
    print('no')