# -*- coding: utf-8 -*-
"""
Created on Sat Mar 14 02:29:51 2020

@author: Arnav
"""

f1=open('test.txt')
lines=f1.readlines()

f1.close()