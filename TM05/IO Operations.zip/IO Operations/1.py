# -*- coding: utf-8 -*-
"""
Created on Sat Mar 14 02:12:02 2020

@author: Arnav
"""

f1=open('test.txt')
print(f1.read())
f1.close()