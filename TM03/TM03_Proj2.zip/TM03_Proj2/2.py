import mymod
x="weatrhbtatbraverweabnrtymyusutr"
ispalindrome(x)
count_the_vowels(x)
frequency_of_letters(x)