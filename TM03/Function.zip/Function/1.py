def sumOfList(x):
    s=0
    for i in x:
       s+=i
    return s

li=[1,2,3,4,5,89]
print(sumOfList(li))