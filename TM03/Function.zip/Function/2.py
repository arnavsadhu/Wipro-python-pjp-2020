def revString(x):
    n=len(x)
    s=x[n::-1]
    return s

li="Hello Everyone"
print(revString(li))